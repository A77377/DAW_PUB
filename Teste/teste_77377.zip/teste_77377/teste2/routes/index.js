var express = require('express');
var router = express.Router();
var axios = require('axios');

/* GET home page. */
router.get('/', function (req, res, next) {
    axios.get('http://clav-test.di.uminho.pt/api/classes/nivel/1')
        .then(data => res.render('index', { fstlvl: data.data }))
        .catch(error => res.render('error', { error: error }))
});

function getFstClassData() {
    return 
}

router.get('/fst/:cid', (req, res, next) => {
    axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.cid)
        .then(data =>  {
            var classInfo = data.data;
            classInfo = classInfo[0];
            console.log(classInfo);
            console.log('----------------');
            axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.cid + '/descendencia')
            .then(descdata => {
                var descInfo = descdata.data;
                console.log(descInfo);
                res.render('fst', {classInfo: classInfo, descInfo: descInfo});
            })
            .catch(error => res.render('error', { error: error }));
        })
        .catch(error => res.render('error', { error: error }));
});

router.get('/snd/:cid', (req, res, next) => {
    axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.cid)
        .then(data =>  {
            var classInfo = data.data;
            classInfo = classInfo[0];
            console.log(classInfo);
            console.log('----------------');
            axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.cid + '/descendencia')
            .then(descdata => {
                var descInfo = descdata.data;
                console.log(descInfo);
                res.render('snd', {classInfo: classInfo, descInfo: descInfo});
            })
            .catch(error => res.render('error', { error: error }));
        })
        .catch(error => res.render('error', { error: error }));
});

router.get('/third/:cid', (req, res, next) => {
    axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.cid)
        .then(data =>  {
            var classInfo = data.data;
            classInfo = classInfo[0];
            console.log(classInfo);
            console.log('----------------');
            axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.cid + '/descendencia')
            .then(descdata => {
                var descInfo = descdata.data;
                console.log(descInfo);
                res.render('third', {classInfo: classInfo, descInfo: descInfo});
            })
            .catch(error => res.render('error', { error: error }));
        })
        .catch(error => res.render('error', { error: error }));
});

router.get('/fourth/:cid', (req, res, next) => {
    axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.cid)
        .then(data =>  {
            var classInfo = data.data;
            classInfo = classInfo[0];
            res.render('fourth', {classInfo: classInfo});
        })
        .catch(error => res.render('error', { error: error }));
});

module.exports = router;
