var models = require('../../models/schema');
var Composer = models.Composer;

module.exports.listComposers = () => {
    return Composer
        .find({}, {"@id": 1, "nome": 1, "dataNasc": 1, "_id": 0})
        .sort({nome: 1})
        .exec()
}

module.exports.listComposerByPer = per => {
    return Composer
        // Incluo o período para verificar a correção da query.
        .find({"periodo": per}, {"@id": 1, "nome": 1, "dataNasc": 1, "periodo": 1, "_id": 0})
        .sort({nome: 1})
        .exec()
}

module.exports.getComposerByID = id => {
    return Composer
        .findOne({"@id": id}, {})
        .exec()
}

module.exports.listComposerByPerAndDate = (per, date) => {
    return Composer
        .find({"periodo": per, "dataNasc": {$gte: date}}, {"@id": 1, "nome": 1, "dataNasc": 1, "periodo": 1, "_id": 0})
        .sort({nome: 1})
        .exec()
}