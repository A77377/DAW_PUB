var express = require('express');
var router = express.Router();

var Composer = require('../../controllers/api/composers');

router.get('/', (req, res) => {

    var per = req.query.periodo;
    var date = req.query.data;
    console.log(per);
    console.log(date);
    if (date == undefined) {
        console.log('Data indefinida.')
    }

    if (per && date == undefined) {
        Composer.listComposerByPer(per)
            .then(data => res.jsonp(data))
            .catch(error => res.status(500).send('Erro na listagem de compositor por período.'));
    }
    else if (per && date) {
        Composer.listComposerByPerAndDate(per, date)
            .then(data => res.jsonp(data))
            .catch(error => res.status(500).send('Erro na listagem de compositores por data e período.'));
    }
    else {
        Composer.listComposers()
            .then(data => res.jsonp(data))
            .catch(error => res.status(500).send('Erro na listagem de compositores.'));
    }
});

router.get('/:id', (req, res) => {

    Composer.getComposerByID(req.params.id)
        .then(data => res.jsonp(data))
        .catch(error => res.status(500).send('Erro na listagem de compositor por ID.'));
});

module.exports = router;