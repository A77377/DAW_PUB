var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var ComposerSchema = new Schema({
    id: { type: String, required: true },
    nome: { type: String, required: true },
    bio: { type: String, required: true },
    dataNasc: { type: String, required: true },
    dataObito: { type: String, required: true },
    periodo: { type: String, required: true }
});

var Composer = mongoose.model('Composer', ComposerSchema, 'composers');

module.exports = {
    Composer: Composer
};